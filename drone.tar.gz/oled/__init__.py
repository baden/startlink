"""
ssd1306 for Python.
"""

__version__ = '0.2.0'
